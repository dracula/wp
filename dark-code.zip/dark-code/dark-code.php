<?php
/*
Plugin Name: Dark Code
Description: Dark mode for your code.
Version: 0.1
Author: Bryan Hadaway
Author URI: https://calmestghost.com/
Requires at least: 5.0
License: Public Domain
License URI: https://wikipedia.org/wiki/Public_domain
Text Domain: dark-code
*/

// block direct access to this file
if ( !defined( 'ABSPATH' ) ) {
	http_response_code( 404 );
	die();
}

// enqueue styles and scripts
add_action( 'wp_enqueue_scripts', 'dark_enqueue' );
function dark_enqueue() {
	wp_enqueue_style( 'dark-theme', plugin_dir_url( __FILE__ ) . 'dracula.css' );
	wp_register_script( 'dark-highlight', plugin_dir_url( __FILE__ ) . 'highlight.js' );
	wp_enqueue_script( 'dark-highlight' );
	wp_add_inline_script( 'dark-highlight', 'hljs.highlightAll();' );
}

// customizer
add_action( 'customize_register', 'dark_customizer', 20 );
function dark_customizer( $wp_customize ) {
	$wp_customize->add_section(
		'dark_code_styles',
		array(
			'title'    => esc_html__( 'Code Styles', 'dark-code' ),
			'priority' => 45
		)
	);
	$wp_customize->add_setting(
		'dark_background_color',
		array(
			'default' 			=> '282a36',
			'sanitize_callback' => 'sanitize_hex_color'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'background_color',
			array(
				'label'    => esc_html__( 'Background Color', 'dark-code' ),
				'section'  => 'dark_code_styles',
				'settings' => 'dark_background_color'
			)
		)
	);
	$wp_customize->add_setting(
		'dark_comment_color',
		array(
			'default' 			=> '6272a4',
			'sanitize_callback' => 'sanitize_hex_color'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'comment_color',
			array(
				'label'    => esc_html__( 'Comment Color', 'dark-code' ),
				'section'  => 'dark_code_styles',
				'settings' => 'dark_comment_color'
			)
		)
	);
	$wp_customize->add_setting(
		'dark_selector_color',
		array(
			'default' 			=> '8be9fd',
			'sanitize_callback' => 'sanitize_hex_color'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'selector_color',
			array(
				'label'    => esc_html__( 'Selector Color', 'dark-code' ),
				'section'  => 'dark_code_styles',
				'settings' => 'dark_selector_color'
			)
		)
	);
	$wp_customize->add_setting(
		'dark_keyword_color',
		array(
			'default' 			=> 'ff79c6',
			'sanitize_callback' => 'sanitize_hex_color'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'keyword_color',
			array(
				'label'    => esc_html__( 'Keyword Color', 'dark-code' ),
				'section'  => 'dark_code_styles',
				'settings' => 'dark_keyword_color'
			)
		)
	);
	$wp_customize->add_setting(
		'dark_substring_color',
		array(
			'default' 			=> 'f8f8f2',
			'sanitize_callback' => 'sanitize_hex_color'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'substring_color',
			array(
				'label'    => esc_html__( 'Substring Color', 'dark-code' ),
				'section'  => 'dark_code_styles',
				'settings' => 'dark_substring_color'
			)
		)
	);
	$wp_customize->add_setting(
		'dark_attribute_color',
		array(
			'default' 			=> '50fa7b',
			'sanitize_callback' => 'sanitize_hex_color'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'attribute_color',
			array(
				'label'    => esc_html__( 'Attribute Color', 'dark-code' ),
				'section'  => 'dark_code_styles',
				'settings' => 'dark_attribute_color'
			)
		)
	);
	$wp_customize->add_setting(
		'dark_variable_color',
		array(
			'default' 			=> 'f1fa8c',
			'sanitize_callback' => 'sanitize_hex_color'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'variable_color',
			array(
				'label'    => esc_html__( 'Variable Color', 'dark-code' ),
				'section'  => 'dark_code_styles',
				'settings' => 'dark_variable_color'
			)
		)
	);
	$wp_customize->add_setting(
		'dark_number_color',
		array(
			'default' 			=> 'bd93f9',
			'sanitize_callback' => 'sanitize_hex_color'
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'number_color',
			array(
				'label'    => esc_html__( 'Number Color', 'dark-code' ),
				'section'  => 'dark_code_styles',
				'settings' => 'dark_number_color'
			)
		)
	);
}

add_action( 'wp_head', 'dark_customizer_css' );
function dark_customizer_css() {
	?>
	<style>
		.hljs{background:<?php echo esc_html( get_theme_mod( 'dark_background_color' ) ); ?>}
		.hljs-comment,.hljs-deletion,.hljs-quote{color:<?php echo esc_html( get_theme_mod( 'dark_comment_color' ) ); ?>}
		.hljs-built_in,.hljs-link,.hljs-section,.hljs-selector-tag{color:<?php echo esc_html( get_theme_mod( 'dark_selector_color' ) ); ?>}
		.hljs-keyword{color:<?php echo esc_html( get_theme_mod( 'dark_keyword_color' ) ); ?>}
		.hljs,.hljs-subst{color:<?php echo esc_html( get_theme_mod( 'dark_substring_color' ) ); ?>}
		.hljs-attr,.hljs-meta-keyword,.hljs-title{color:<?php echo esc_html( get_theme_mod( 'dark_attribute_color' ) ); ?>}
		.hljs-addition,.hljs-bullet,.hljs-meta,.hljs-name,.hljs-string,.hljs-symbol,.hljs-template-tag,.hljs-template-variable,.hljs-type,.hljs-variable{color:<?php echo esc_html( get_theme_mod( 'dark_variable_color' ) ); ?>}
		.hljs-literal,.hljs-number{color:<?php echo esc_html( get_theme_mod( 'dark_number_color' ) ); ?>}
	</style>
	<?php
}