=== Dark Code ===

Contributors: bhadaway
Donate link: https://calmestghost.com/donate
Tags: dark mode, dracula, highlight.js, code, syntax, highlighting
Requires PHP: 7.0
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 0.1
License: Public Domain
License URI: https://wikipedia.org/wiki/Public_domain

Dark mode for your code.

== Description ==

Dark mode for your code.

By default, the popular Dracula Theme + Highlight.js make for beautifully dark code highlighting on the front-end of your WordPress-powered website. However, you can completely customize the look of code highlighting (under *Appearance > Customize*) if you like, even changing the overall style to, 🧛 (*gasp*), a light mode design.

Simply activate this plugin and any code found within `&lt;pre&gt;&lt;code&gt;...&lt;/code&gt;&lt;/pre&gt;` tags on the front-end of your site will automatically be highlighted according to the detected language.

Dracula: [https://draculatheme.com/](https://draculatheme.com/)
Highlight.js: [https://highlightjs.org/](https://highlightjs.org/)

== Changelog ==

= 0.1 =
* New