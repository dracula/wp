<?php
/*
Plugin Name: Dracula
Description: The popular Dracula Theme + Highlight.js make for beautifully dark code highlighting on the front-end of your WordPress-powered website.
Version: 0.1
Author: Bryan Hadaway
Author URI: https://calmestghost.com/
Requires at least: 5.0
License: Public Domain
License URI: https://wikipedia.org/wiki/Public_domain
Text Domain: dracula
*/

// block direct access to this file
if ( !defined( 'ABSPATH' ) ) {
	http_response_code( 404 );
	die();
}

// enqueue styles and scripts
add_action( 'wp_enqueue_scripts', 'dracula_enqueue' );
function dracula_enqueue() {
	wp_enqueue_style( 'dracula-theme', plugin_dir_url( __FILE__ ) . 'dracula.css' );
	wp_register_script( 'dracula-highlight', plugin_dir_url( __FILE__ ) . 'highlight.js' );
	wp_enqueue_script( 'dracula-highlight' );
	wp_add_inline_script( 'dracula-highlight', 'hljs.highlightAll();' );
}