=== Dracula ===

Contributors: bhadaway
Donate link: https://calmestghost.com/donate
Tags: dracula, highlight.js, code, syntax, highlighting
Requires PHP: 7.0
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 0.1
License: Public Domain
License URI: https://wikipedia.org/wiki/Public_domain

The popular Dracula Theme + Highlight.js make for beautifully dark code highlighting on the front-end of your WordPress-powered website.

== Description ==

The popular Dracula Theme + Highlight.js make for beautifully dark code highlighting on the front-end of your WordPress-powered website.

Simply activate this plugin and any code found within `&lt;pre&gt;&lt;code&gt;...&lt;/code&gt;&lt;/pre&gt;` tags on the front-end of your site will automatically be highlighted according to the detected language.

Dracula: https://draculatheme.com/
Highlight.js: https://highlightjs.org/

== Changelog ==

= 0.1 =
* New